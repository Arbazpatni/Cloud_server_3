#!/bin/bash
#######################################################################
# File name : setup.sh 
# Author : Arbazpatni (24/10/2022)
# Author email : sowmiyancloud@gmail.com
# Project : CashFactory
# Project repository : https://github.com/Arbazpatni/Cloud_Server_3/CashFactory.tar.gz
# 
# Setup script for docker environment
#######################################################################

# install and setup docker on the host, the following command will need a sudo to correctly run : sudo ./setup.sh
sudo apt update
sudo apt upgrade
sudo apt-get remove docker docker-engine docker.io containerd runc
sudo apt-get update
sudo apt-get install \
    ca-certificates \
    curl \
    gnupg \
    lsb-release

sudo mkdir -p /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/debian/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg

echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/debian \
  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
  
  
sudo apt-get update

#If you get any error run this
#sudo chmod a+r /etc/apt/keyrings/docker.gpg
#sudo apt-get update

sudo apt-get install docker-ce docker-ce-cli containerd.io docker-compose-plugin

systemctl enable docker.service

mkdir -p data/bitping #create data directory for bitping credentials


